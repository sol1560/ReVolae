"""CuaRemote iPad dongle。"""
